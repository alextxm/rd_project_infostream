﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using TK.SPTools.CAMLBuilder.Expressions;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Expression exp = Operator.And(
                                Criteria.Contains("fieldA", "string", "valueForA"),
                                Criteria.Contains("fieldB", "string", "valueForB"),
                                Operator.Or(
                                    Criteria.Contains("fieldC", "string", "valueForC"),
                                    Criteria.Contains("fieldD", "string", "valueForD")
                                    )
                                );

            string c = exp.GetCAML();
            string q = exp.GetCAMLQuery();
        }
    }
}
